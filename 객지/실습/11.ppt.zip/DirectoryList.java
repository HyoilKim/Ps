package file;

import java.io.File;

public class DirectoryList {
	public static void main(String[] args) {
		File file = new File("Test");

		if (file.exists()) {
			File[] files = file.listFiles();

			for (File f : files) {
				String str = f.getName();

				if (f.isDirectory()) {
					System.out.print(str + "\t\t<DIR>\n");
				} else {
					System.out.print(str + "\t" + f.length() + " bytes\n");
				}
			}
		} else {
			System.exit(0);
		}
	}
}