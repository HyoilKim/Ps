import java.io.FileInputStream;
import java.io.IOException;

public class SystemInDemo {
	public static void main(String[] args) throws IOException {
		FileInputStream file = new FileInputStream("File.txt");
		System.setIn(file);
		
		int i = 0;
		while ((i = System.in.read()) != -1) {
			System.out.print((char) i);
		}
		file.close();
	}
}