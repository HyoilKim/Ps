package Anonymous;

public class Main {
	public static void main(String [] args) {
		Test t1 = new Test();
		
		Test t2 = new Test() {
			public int num =10;
			
			@Override
			public int getNum() {
				return this.num;
			}
		};
		
		System.out.println(t1.getNum());
		System.out.println(t2.getNum());
		
		t2.setNum(5);
		
		System.out.println(t2.getNum());
	}
}
