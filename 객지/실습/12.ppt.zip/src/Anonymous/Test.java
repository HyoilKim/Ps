package Anonymous;

class Test{
	
	private int num = 1; 
	
	public int getNum(){ 
		return this.num; 
	} 
	
	public void setNum(int num){
		this.num = num; 
	} 
}

