
public interface BurgerCook {
    public void makeBurger();
    public void makeSalad();
}
