package Inconsistencies;

public interface MyInterface  {
	
	static double value3 = 3.0;
	
	public abstract String MyAbstract();
	
	String MyAbstract2(String a, String b);
	
}


