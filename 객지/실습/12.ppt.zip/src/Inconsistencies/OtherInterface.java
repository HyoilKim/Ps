package Inconsistencies;


public interface OtherInterface {

	static double value3 = 4.0;
	
	public abstract void MyAbstract();
	
	public abstract String OtherMethod();
	
	
	
}

