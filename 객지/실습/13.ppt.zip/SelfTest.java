import java.util.ArrayList;
import java.util.Random;

public class SelfTest {
	public static void main(String[] args) {
		Random random = new Random();
		ArrayList<Integer> lottoNumber = new ArrayList<Integer>(6);

		for (int i = 0; i < 6; i++) {
			lottoNumber.add(random.nextInt(45) + 1);
			
			for (int j = 0; j < i; j++) {
				if (lottoNumber.get(j) == lottoNumber.get(i)) {
					lottoNumber.remove(i);
					i--;
					break;
				}
			}
		}
		
		lottoNumber.sort(null);
		
		for (int i : lottoNumber) {
			System.out.print(i + " ");
		}
	}
}
