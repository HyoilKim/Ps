
public class StudentDemo {
	public static void main(String[] args) {
		Student jeonghunLee = new Student("������", "Computer softwar", 20190001, "930322", "010-1234-5678");
		jeonghunLee.studentImpormation();
		jeonghunLee.changeId();
		jeonghunLee.changePassword();
		jeonghunLee.login();
		
		Student gildongHong = new Student("ȫ�浿", "Korean language and literature", 16120001, "120101");
		gildongHong.studentImpormation();
		gildongHong.changeId();
		gildongHong.changePassword();
		gildongHong.login();
	}
}