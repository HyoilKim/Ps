package oojp;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class BufferedReaderWriterTest {
	public static void main(String[] args){
		
		try {
			FileReader fr = new FileReader("sample.txt");
			BufferedReader br = new BufferedReader(fr);
			FileWriter fw = new FileWriter("output.txt");
			BufferedWriter bw = new BufferedWriter(fw);
			String readLine = br.readLine();
			while(readLine != null){
				System.out.println(readLine);
				bw.write(readLine);
				bw.newLine();
				readLine = br.readLine();
			}
			
			br.close();
			fr.close();
			bw.close();
			fw.close();
		}catch(FileNotFoundException e) {
			e.getStackTrace();
		}catch(IOException e2) {
			e2.getStackTrace();
		}
	}
}
