package oojp;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Scanner;

public class test2 {

	public static void main(String[] args) {
		
		Scanner fileIn = null;
		String str;
		int number;
		try {
		fileIn = new Scanner ( new FileInputStream("test2.txt"));
		FileOutputStream fos = new FileOutputStream("output2.txt");
		while(fileIn.hasNextInt()) {
			number = fileIn.nextInt()*100;
			String bytenumber = Integer.toString(number);
			System.out.println(bytenumber.getBytes());
			fos.write(bytenumber.getBytes());
			fos.write("\r\n".getBytes());
			
			
			
		}
		fileIn.nextLine();
		str =fileIn.nextLine();
		str = str.toUpperCase();
		fos.write(str.getBytes());
		fos.close();
		}catch(FileNotFoundException e){
		System.exit(0);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
