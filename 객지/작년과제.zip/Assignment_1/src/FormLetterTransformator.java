import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;

public class FormLetterTransformator {
    public static void main(String[] args) throws IOException {
    	String enter = String.format("%n");
        BufferedReader brProperties = new BufferedReader(new FileReader("properties.txt"));
        LinkedList<KeyValue> template = new LinkedList<KeyValue>();

        while(true) {
            String propertiesLine = brProperties.readLine();
            if( propertiesLine == null) break;
            else {
                template.add(new KeyValue(propertiesLine));
            }
        }
        brProperties.close();

        BufferedReader brTemplate = new BufferedReader(new FileReader("template_file.txt"));

        StringBuffer buf = new StringBuffer();
        while(true) {
            String templateLine = brTemplate.readLine();
            if( templateLine == null) break;
            else {
                buf.append(templateLine+enter);
            }
        }
        brTemplate.close();

        String outputString = buf.toString();

        for(KeyValue e : template){
            outputString = outputString.replace("{"+e.getKey()+"}", e.getValue());
        }

        FileOutputStream output = new FileOutputStream("output_file.txt");

        output.write(outputString.getBytes("UTF-8"));

        output.close();
    }
}