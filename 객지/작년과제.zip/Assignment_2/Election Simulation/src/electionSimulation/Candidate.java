package electionSimulation;

public class Candidate extends Student {
	
	private int numOfVotes;
	
	public Candidate(Student student) {
		this.setName(student.getName());
		this.setStudentDepartment(student.getStudentDepartment());
		this.setStudentId(student.getStudentId());
		numOfVotes = 0;
		this.getStudentDepartment().addCand(this);
	}
	
	public int getNumOfVotes() {
		return numOfVotes;
	}
	
	public void voted() {
		numOfVotes++;
	}
	
	@Override
	public int compareTo(Candidate arg0) {
		// TODO Auto-generated method stub
		return  arg0.getNumOfVotes()-this.numOfVotes;
	}
}
