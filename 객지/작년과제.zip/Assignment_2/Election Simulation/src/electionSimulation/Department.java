package electionSimulation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
//import java.util.Iterator;

public class Department {
	private String name;
	private int id;
	private ArrayList<Candidate> CandidateList;
	private ArrayList<Student> StudentList;
	
	public Department(int id, String name) {
		this.name = name;
		this.id = id;
		CandidateList = new ArrayList<Candidate>();
		StudentList = new ArrayList<Student>();
		
		//System.out.println("Dep "+this.id+" "+this.name+" created.");
	}
	
//	public ArrayList<Student> getStudentList() {
//		return StudentList;
//	}
	
	public String getName() {
		return name;
	}
	
	public int getCandSize() {
		return CandidateList.size();
	}
	
	public void voteTo(int index) {
		CandidateList.get(index).voted();
	}
	
	public int getId() {
		return id;
	}
	
	public boolean equals(Department arg0) {
		// TODO Auto-generated method stub
		return this.id == arg0.getId();
	}
	
	public Candidate Electe() {
//		Iterator<Candidate> it = CandidateList.iterator();
//		while(it.hasNext()) {
//			
//		}
		Iterator<Student> stuIt = StudentList.iterator();
		while(stuIt.hasNext()) {
			stuIt.next().vote();
		}
		
		Candidate[] a = CandidateList.toArray(new Candidate[0]);
		Arrays.sort(a);
		return a[0];		
	}
	
	public void addStu(Student student) {
		StudentList.add(student);
	}
	
	public void addCand(Candidate candidate) {
		CandidateList.add(candidate);
	}
}
