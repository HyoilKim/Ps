package electionSimulation;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.StringTokenizer;

public class ElectionSim {

	private String depInputPath;
	private String stuInputPath;
	private String outputPath;
	
	private ArrayList<Department> DepList;
	private ArrayList<Candidate> ElectedList;
	
	public ElectionSim(String depInputPath, String stuInputPath, String outputPath) {
		
		this.depInputPath=depInputPath;
		this.stuInputPath=stuInputPath;
		this.outputPath=outputPath;
		
		DepList = new ArrayList<Department>();
		ElectedList = new ArrayList<Candidate>();
		
		try{
			BufferedReader depIn = new BufferedReader(new InputStreamReader(new FileInputStream(this.depInputPath),"UTF8"));
			String DepStr = depIn.readLine();
			DepStr = depIn.readLine();
			while(DepStr != null) {
				StringTokenizer st1 = new StringTokenizer(DepStr,",");
				int id = Integer.parseInt(st1.nextToken());
				String depName = st1.nextToken();
				//System.out.println(id+depName);
				DepList.add(new Department(id,depName));
				DepStr = depIn.readLine();
			}
			
			depIn.close();
			
			BufferedReader stuIn = new BufferedReader(new InputStreamReader(new FileInputStream(this.stuInputPath),"UTF8"));
			String StuStr = stuIn.readLine();
			while((StuStr = stuIn.readLine()) != null) {
				StringTokenizer st2 = new StringTokenizer(StuStr, ",");
				
				int stuId = Integer.parseInt(st2.nextToken());
				int depId = Integer.parseInt(st2.nextToken());
				Iterator<Department> DepItTemp = DepList.iterator();
				Department Dep = null;
				while(DepItTemp.hasNext()) {
					Dep = DepItTemp.next();
					if(Dep.getId() == depId) break;
				}
				new Student(stuId,Dep,st2.nextToken(),st2.nextToken());
			}
			
			stuIn.close();
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void saveData() {
		File of = new File(outputPath);
		BufferedWriter bw = null;
		try {
			bw = new BufferedWriter(new FileWriter(of));
			Candidate[] a = ElectedList.toArray(new Candidate[0]);
			Arrays.sort(a);
			for(int i = 0; i < a.length; i++) {
				bw.write("======== Elected Candidate ========");
				System.out.println("======== Elected Candidate ========");
				bw.newLine();
				bw.write("Department name: "+a[i].getStudentDepartment().getName());
				System.out.println("Department name: "+a[i].getStudentDepartment().getName());
				bw.newLine();
				bw.write("name: "+a[i].getName());
				System.out.println("name: "+a[i].getName());
				bw.newLine();
				bw.write("Student_id: "+a[i].getStudentId());
				System.out.println("Student_id: "+a[i].getStudentId());
				bw.newLine();
				bw.write("Votes: "+a[i].getNumOfVotes());
				System.out.println("Votes: "+a[i].getNumOfVotes());
				bw.newLine();
				bw.write("===================================");
				System.out.println("===================================");
				bw.newLine();
			}
			//bw.write("fin");
			bw.flush();
			bw.close();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void runSimulation() {
		Iterator<Department> depIt = DepList.iterator();
//		ArrayList<Student> studentList = null;
		while(depIt.hasNext()) {
			ElectedList.add(depIt.next().Electe());
		}
		saveData();
	}
	
}
