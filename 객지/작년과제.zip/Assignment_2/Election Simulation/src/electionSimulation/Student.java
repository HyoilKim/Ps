package electionSimulation;

import java.util.Random;

public class Student implements Voter {
	
	private String name;
	private int StudentId;
	private Department studentDepartment;
	
	public void setName(String name) {
		this.name = name;
	}
	public void setStudentId(int studentId) {
		StudentId = studentId;
	}
	public void setStudentDepartment(Department studentDepartment) {
		this.studentDepartment = studentDepartment;
	}
	public String getName() {
		return name;
	}
	public Department getStudentDepartment() {
		return studentDepartment;
	}
	public int getStudentId() {
		return StudentId;
	}
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	public Student(int StudentId,Department studentDepartment,String name, String bool) {
		this.StudentId = StudentId;
		this.studentDepartment = studentDepartment;
		this.name = name;
		
		if(bool.equals("TRUE") || bool.equals("1")) {
			new Candidate(this);
		}
		
		this.studentDepartment.addStu(this);
		
	}


	@Override
	public void vote() {
		// TODO Auto-generated method stub
		Random rand = new Random();
		int index = rand.nextInt(studentDepartment.getCandSize());
		
		studentDepartment.voteTo(index);		
	}




	@Override
	public int compareTo(Candidate arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

}
