package electionSimulation;

public interface Voter extends Comparable<Candidate> {
	public void vote();
}
